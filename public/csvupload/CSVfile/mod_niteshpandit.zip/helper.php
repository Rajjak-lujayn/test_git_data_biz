<?php
/**
 * @copyright	Copyright (c) 2022 login . All rights reserved.
 * @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

// no direct access
defined('_JEXEC') or die;

/**
 * login  - nitesh pandit Helper Class.
 *
 * @package		Joomla.Site
 * @subpakage	login.niteshpandit
 */
class modniteshpanditHelper {
	
}